To run this program, make sure it has executable permissions:
	$ chmod u+x align

Finally, run the program:
	$ ./align

